package pkg

import "github.com/jackc/pgx/v4/pgxpool"

var Conn *pgxpool.Pool
