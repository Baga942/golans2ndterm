package core

type Order struct {
 Id int
 Sum int
 Destination string
}