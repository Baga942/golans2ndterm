package repositories

import (
	"Visitor/core"
	"Visitor/core/interfaces"
	"context"
	"github.com/jackc/pgx/v4/pgxpool"
	"log"
)

type VisitorRepository struct {
	pool pgxpool.Pool
}

func (r *VisitorRepository) CreateVisitor(visitor core.Visitor) bool {
	panic("implement me")
}

func NewVisitorRepository(conn *pgxpool.Pool) interfaces.IVisitorsRepository {
	return &VisitorRepository{*conn}
}

func (r *VisitorRepository) CreateUser(user core.Visitor) bool {
	sql := "INSERT INTO visitor(name, surname, username) VALUES($2, $3, $4) RETURNING id"
	row := r.pool.QueryRow(context.Background(), sql, user.Name, user.Surname, user.Username)
	var id int
	err := row.Scan(&id)
	if err != nil{
		log.Printf("Unable to Insert: %v\n", err)
		return false
	}
	return true

}

func (r *VisitorRepository) GetAllVisitors() []*core.Visitor {
	stmt := "SELECT * FROM visitor"
	rows, err := r.pool.Query(context.Background(), stmt)
	if err != nil {
		log.Fatal("Failed to SELECT:", err)
		return nil
	}
	defer rows.Close()
	visitors := []*core.Visitor{}
	for rows.Next() {
		u := &core.Visitor{}
		err = rows.Scan(&u.Id, &u.Name, &u.Surname, &u.Username)
		if err != nil {
			log.Fatalf("Failed to scan: %v", err)
			return nil
		}
		visitors = append(visitors, u)
	}
	if err = rows.Err(); err != nil {
		return nil
	}
	return visitors
}

func (r *VisitorRepository) GetVisitorById(id int) *core.Visitor {
	stmt := "SELECT * FROM visitor WHERE id = $1"
	u := &core.Visitor{}
	err := r.pool.QueryRow(context.Background(), stmt, id).Scan(&u.Id, &u.Name, &u.Surname, &u.Username)
	if err != nil {
		log.Println("Didn't find user with id ", id)
		return nil
	}
	return u
}

func (r *VisitorRepository) DeleteVisitor(visitor core.Visitor) bool {
	_, err := r.pool.Exec(context.Background(), "DELETE FROM visitor WHERE id = $1", visitor.Id)
	if err != nil {
		return false
	}
	return true
}

func (r *VisitorRepository) UpdateVisitor(visitor core.Visitor) bool {
	_, err := r.pool.Exec(context.Background(), "UPDATE visitor SET name = $1, surname = $2, username = $3 WHERE id = $4",
		visitor.Name, visitor.Surname, visitor.Username, visitor.Id)
	if err != nil {
		return false
	}
	return true
}