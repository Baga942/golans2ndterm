package main

import (
	"Visitor/core"
	"Visitor/core/interfaces"
	"github.com/gin-gonic/gin"
	"strconv"
)

var jsonContentType = "application/json; charset=utf-8"
var visitorRepository interfaces.IVisitorsRepository

func RouteVisitors(router *gin.Engine)  {
	router.GET("/visitors", GetAllVisitors)
	router.GET("/visitors/:id", GetVisitorById)
	router.POST("/visitors", CreateVisitor)
	router.DELETE("/visitors/:id", DeleteVisitor)
	router.PUT("/visitors/:id", UpdateVisitor)
}

func GetAllVisitors(context *gin.Context)  {
	visitors := visitorRepository.GetAllVisitors()
	context.JSON(200, visitors)
}

func GetVisitorById(context *gin.Context){
	id, err := strconv.Atoi(context.Param("id"))
	if err != nil || id < 1 {
		context.Data(400, jsonContentType, []byte("Incorrect id format"))
		return
	}
	visitor := visitorRepository.GetVisitorById(id)
	context.JSON(200, visitor)
}

func CreateVisitor(context *gin.Context) {
	visitor := &core.Visitor{}
	err := context.BindJSON(visitor)
	if err != nil {
		context.Data(400, jsonContentType, []byte("Fill all fields"))
		return
	}
	if visitorRepository.CreateVisitor(*visitor) {
		context.Data(200, jsonContentType, []byte("Created visitor \n"))
	}
	context.Data(500, jsonContentType, []byte("Failed to create visitor"))
}

func DeleteVisitor(context *gin.Context) {
	id, err := strconv.Atoi(context.Param("id"))
	if err != nil || id < 1 {
		context.Data(400, jsonContentType, []byte("Incorrect id format"))
		return
	}
	visitor := visitorRepository.GetVisitorById(id)
	if visitor == nil {
		context.Data(400, jsonContentType, []byte("No such visitor with id"))
		return
	}
	if visitorRepository.DeleteVisitor(*visitor) {
		context.Data(200, jsonContentType, []byte("Deleted visitor"))
		return
	}
	context.Data(500, jsonContentType, []byte("Failed to delete visitor"))
}

func UpdateVisitor(context *gin.Context) {
	id, err := strconv.Atoi(context.Param("id"))
	if err != nil || id < 1 {
		context.Data(400, jsonContentType, []byte("Incorrect id format"))
		return
	}
	model := visitorRepository.GetVisitorById(id)
	visitor := &core.Visitor{}
	err = context.BindJSON(visitor)
	if err != nil {
		context.Data(400, jsonContentType, []byte("Fill all fields"))
		return
	}
	visitor.Id = id
	updateValues(model, visitor)
	if visitorRepository.UpdateVisitor(*visitor) {
		context.Data(200, jsonContentType, []byte("Updated visitor"))
		return
	}
	context.Data(500, jsonContentType, []byte("Failed to update visitor"))
}

func updateValues(visitor *core.Visitor, updateVisitor *core.Visitor)  {
	if len(updateVisitor.Name) > 0 {
		visitor.Name = updateVisitor.Name
	}
	if len(updateVisitor.Surname) > 0 {
		visitor.Surname = updateVisitor.Surname
	}
	if len(updateVisitor.Username) > 0 {
		visitor.Username = updateVisitor.Username
	}
}