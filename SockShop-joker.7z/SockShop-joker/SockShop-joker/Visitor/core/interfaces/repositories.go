package interfaces

import "Visitor/core"

type IVisitorsRepository interface {
	CreateVisitor(visitor core.Visitor) bool
	GetAllVisitors() []*core.Visitor
	GetVisitorById(visitor int) *core.Visitor
	DeleteVisitor(visitor core.Visitor) bool
	UpdateVisitor(visitor core.Visitor) bool
}