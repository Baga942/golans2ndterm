package core

type Visitor struct {
	Id int
	Name string
	Surname string
	Username string
}
