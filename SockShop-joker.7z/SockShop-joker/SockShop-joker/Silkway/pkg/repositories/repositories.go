package repositories

import (
	"Silkway/core"
	"Silkway/core/interfaces"
	"context"
	"github.com/jackc/pgx/v4/pgxpool"
	"log"
)

type DrinkRepository struct {
	pool pgxpool.Pool
}

func NewDrinkRepository(conn *pgxpool.Pool) interfaces.IDrinksRepository {
	return &DrinkRepository{*conn}
}
func (r *DrinkRepository) CreateDrinks(drink core.Drink) bool {
	sql := "INSERT INTO drink(name, price, quantity) VALUES($1, $2, $3) RETURNING id"
	row := r.pool.QueryRow(context.Background(), sql, drink.Name, drink.Price, drink.Quantity)
	var id int
	err := row.Scan(&id)
	if err != nil {
		log.Printf("Unable to INSERT: %v\n", err)
		return false
	}
	return true
}

func (r DrinkRepository) GetAllDrinks() []*core.Drink {
	stmt := "SELECT * FROM drink"
	rows, err := r.pool.Query(context.Background(), stmt)
	if err != nil {
		log.Fatal("Failed to SELECT:", err)
		return nil
	}
	defer rows.Close()
	drinks := []*core.Drink{}
	for rows.Next() {
		s := &core.Drink{}
		err = rows.Scan(&s.Id, &s.Name, &s.Price, &s.Quantity)
		if err != nil {
			log.Fatalf("Failed to scan: %v", err)
			return nil
		}
		drinks = append(drinks, s)
	}
	if err = rows.Err(); err != nil {
		return nil
	}
	return drinks
}
func (r *DrinkRepository) GetDrinksById(id int) *core.Drink {
	stmt := "SELECT * FROM drink WHERE id = $1"
	s := &core.Drink{}
	err := r.pool.QueryRow(context.Background(), stmt, id).Scan(&s.Id, &s.Name, &s.Price, &s.Quantity)
	if err != nil {
		log.Println("Didn't find user with id ", id)
		return nil
	}
	return s
}

func (r *DrinkRepository) DeleteDrinks(drink core.Drink) bool {
	_, err := r.pool.Exec(context.Background(), "DELETE FROM drink WHERE id = $1", drink.Id)
	if err != nil {
		return false
	}
	return true
}
func (r DrinkRepository) UpdateDrinks(drink core.Drink) bool {
	_, err := r.pool.Exec(context.Background(), "UPDATE drink SET name = $1, price = $2, quantity = $3 WHERE id = $4",
		drink.Name, drink.Price, drink.Quantity, drink.Id)
	if err != nil {
		return false
	}
	return true
}
