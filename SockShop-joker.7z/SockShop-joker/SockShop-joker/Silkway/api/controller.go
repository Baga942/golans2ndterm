package main

import (
	"Silkway/core"
	"Silkway/core/interfaces"
	"github.com/gin-gonic/gin"
	"strconv"
)
var jsonContentType = "application/json; charset=utf-8"
var drinkRepository interfaces.IDrinksRepository

func RouteDrinks(router *gin.Engine)  {
	router.GET("/drinks", GetAllDrinks)
	router.GET("/drinks/:id", GetDrinksById)
	router.POST("/drinks", CreateDrinks)
	router.DELETE("/drinks/:id", DeleteDrinks)
	router.PUT("/drinks/:id", UpdateDrinks)
}

func GetAllDrinks(context *gin.Context)  {
	drinks := drinkRepository.GetAllDrinks()
	context.JSON(200, drinks)
}

func GetDrinksById(context *gin.Context)  {
	id, err := strconv.Atoi(context.Param("id"))
	if err != nil || id < 1 {
		context.Data(400, jsonContentType, []byte("Incorrect id format"))
		return
	}
	drink := drinkRepository.GetDrinksById(id)
	context.JSON(200, drink)
}

func CreateDrinks(context *gin.Context)  {
	drink := &core.Drink{}
	err := context.BindJSON(drink)
	if err != nil {
		context.Data(400, jsonContentType, []byte("Fill all fields"))
		return
	}
	if drinkRepository.CreateDrinks(*drink) {
		context.Data(200, jsonContentType, []byte("Created drink \n"))
	}
	context.Data(500, jsonContentType, []byte("Failed to create drink"))
}

func DeleteDrinks(context *gin.Context)  {
	id, err := strconv.Atoi(context.Param("id"))
	if err != nil || id < 1 {
		context.Data(400, jsonContentType, []byte("Incorrect id format"))
		return
	}
	drink := drinkRepository.GetDrinksById(id)
	if drink == nil {
		context.Data(400, jsonContentType, []byte("No such drink with id"))
		return
	}
	if drinkRepository.DeleteDrinks(*drink) {
		context.Data(200, jsonContentType, []byte("Deleted drink"))
		return
	}
	context.Data(500, jsonContentType, []byte("Failed to delete drink"))
}

func UpdateDrinks(context *gin.Context)  {
	id, err := strconv.Atoi(context.Param("id"))
	if err != nil || id < 1 {
		context.Data(400, jsonContentType, []byte("Incorrect id format"))
		return
	}
	model := drinkRepository.GetDrinksById(id)
	drink := &core.Drink{}
	err = context.BindJSON(drink)
	if err != nil {
		context.Data(400, jsonContentType, []byte("Fill all fields"))
		return
	}
	drink.Id = id
	updateValues(model, drink)
	if drinkRepository.UpdateDrinks(*drink) {
		context.Data(200, jsonContentType, []byte("Updated drink"))
		return
	}
	context.Data(500, jsonContentType, []byte("Failed to update drink"))
}

func updateValues(drink *core.Drink, updateDrinks *core.Drink)  {
	if len(updateDrinks.Name) > 0 {
		drink.Name = updateDrinks.Name
	}
	if updateDrinks.Price > 0 {
		drink.Price = updateDrinks.Price
	}
	if updateDrinks.Quantity > 0 {
		drink.Quantity = updateDrinks.Quantity
	}
}
