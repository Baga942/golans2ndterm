package interfaces

import "Silkway/core"

type IDrinksRepository interface {
	CreateDrinks(drink core.Drink) bool
	GetAllDrinks() []*core.Drink
	GetDrinksById(drink int) *core.Drink
	DeleteDrinks(drink core.Drink) bool
	UpdateDrinks(drink core.Drink) bool
}
