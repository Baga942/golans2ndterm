package core

type Drink struct {
 Id int
 Name string
 Price int
 Quantity int
}